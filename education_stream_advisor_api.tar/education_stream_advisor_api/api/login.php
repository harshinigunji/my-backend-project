
<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");
include("../config/db.php");
header("Content-Type: application/json");

$data = json_decode(file_get_contents("php://input"), true);

$email = $data['email'] ?? '';
$password = $data['password'] ?? '';

if (!$email || !$password) {
    echo json_encode(["status" => false, "error" => "Email and password required"]);
    exit;
}

$res = mysqli_query($conn, "
SELECT user_id, password
FROM users
WHERE email = '$email'
");

if (mysqli_num_rows($res) == 0) {
    echo json_encode(["status" => false, "error" => "Invalid credentials"]);
    exit;
}

$user = mysqli_fetch_assoc($res);

if (!password_verify($password, $user['password'])) {
    echo json_encode(["status" => false, "error" => "Invalid credentials"]);
    exit;
}

/* Generate simple token */
$token = bin2hex(random_bytes(32));

mysqli_query($conn, "
UPDATE users SET auth_token = '$token'
WHERE user_id = {$user['user_id']}
");

echo json_encode([
    "status" => true,
    "user_id" => $user['user_id'],
    "token" => $token
]);

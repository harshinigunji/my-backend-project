<?php
include("../config/db.php");
header("Content-Type: application/json");

$data = json_decode(file_get_contents("php://input"), true);

$user_id = (int)$data['user_id'];
$current_level_id = (int)$data['current_level_id'];
$target_job_id = (int)$data['target_job_id'];
$steps = $data['steps'];

if (!$user_id || !$steps || count($steps) == 0) {
    echo json_encode(["status" => false, "error" => "Invalid input"]);
    exit;
}

/* -------------------------
   CREATE ROADMAP
-------------------------- */
mysqli_query($conn, "
INSERT INTO roadmaps (user_id, current_level_id, target_job_id)
VALUES ($user_id, $current_level_id, $target_job_id)
");

$roadmap_id = mysqli_insert_id($conn);
$step_order = 1;

/* -------------------------
   INSERT USER STEPS
-------------------------- */
foreach ($steps as $step) {

    $type = mysqli_real_escape_string($conn, $step['type']);
    $value = mysqli_real_escape_string($conn, $step['value']);

    if ($type === "education") {
        mysqli_query($conn, "
        INSERT INTO roadmap_steps (roadmap_id, step_order, step_type, education_stage)
        VALUES ($roadmap_id, $step_order, 'education', '$value')
        ");
    }

    if ($type === "exam") {
        mysqli_query($conn, "
        INSERT INTO roadmap_steps (roadmap_id, step_order, step_type, exam_name)
        VALUES ($roadmap_id, $step_order, 'exam', '$value')
        ");
    }

    if ($type === "job") {
        mysqli_query($conn, "
        INSERT INTO roadmap_steps (roadmap_id, step_order, step_type, stream_name)
        VALUES ($roadmap_id, $step_order, 'job', '$value')
        ");
    }

    $step_order++;
}

echo json_encode([
    "status" => true,
    "roadmap_id" => $roadmap_id,
    "message" => "User roadmap created successfully"
]);

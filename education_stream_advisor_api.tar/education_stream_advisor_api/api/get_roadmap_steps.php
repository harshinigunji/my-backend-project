<?php
include("../config/db.php");
header("Content-Type: application/json");

$roadmap_id = $_GET['roadmap_id'];

$res = mysqli_query($conn, "
SELECT step_order,
       education_stage,
       stream_name,
       exam_name
FROM roadmap_steps
WHERE roadmap_id = $roadmap_id
ORDER BY step_order
");

if (!$res) {
    echo json_encode([
        "status" => false,
        "error" => mysqli_error($conn)
    ]);
    exit;
}

$data = [];
while ($row = mysqli_fetch_assoc($res)) {
    $data[] = $row;
}

echo json_encode([
    "status" => true,
    "data" => $data
]);

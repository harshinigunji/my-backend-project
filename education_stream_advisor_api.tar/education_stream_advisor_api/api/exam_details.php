<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

include("../config/db.php");

$exam_id = $_GET['exam_id'];

$res = mysqli_query($conn, "SELECT * FROM entrance_exams WHERE exam_id = $exam_id");
echo json_encode(mysqli_fetch_assoc($res));

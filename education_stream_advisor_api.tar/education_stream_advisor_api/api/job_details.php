<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

include("../config/db.php");

$job_id = $_GET['job_id'];

$res = mysqli_query($conn, "SELECT * FROM jobs WHERE job_id = $job_id");
echo json_encode(mysqli_fetch_assoc($res));

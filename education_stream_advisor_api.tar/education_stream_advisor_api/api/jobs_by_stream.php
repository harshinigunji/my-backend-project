<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

include("../config/db.php");

$stream_id = $_GET['stream_id'];

$sql = "
SELECT j.job_id, j.job_title, j.sector
FROM stream_jobs sj
JOIN jobs j ON sj.job_id = j.job_id
WHERE sj.stream_id = $stream_id
";

$res = mysqli_query($conn, $sql);
$data = [];

while ($row = mysqli_fetch_assoc($res)) {
    $data[] = $row;
}

echo json_encode($data);

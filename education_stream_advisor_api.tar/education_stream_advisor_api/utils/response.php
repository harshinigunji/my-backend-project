<?php
function sendResponse($status, $data) {
    echo json_encode([
        "status" => $status,
        "data" => $data
    ]);
}
?>

# Education Stream Advisor – API Contract (v1)

Base URL:
http://localhost/education_stream_advisor_api/api/

---

## AUTH

POST /register.php
POST /login.php

---

## EDUCATION FLOW

GET /education_levels.php
GET /streams_by_level.php?level_id={id}
GET /stream_details.php?stream_id={id}

---

## EXAMS

GET /exams_by_stream.php?stream_id={id}
GET /exam_details.php?exam_id={id}

---

## JOBS

GET /jobs_by_stream.php?stream_id={id}
GET /job_details.php?job_id={id}

---

## STREAM PROGRESSION

GET /get_next_streams.php?stream_id={id}

---

## ROADMAPS

POST /generate_roadmap_v4.php
POST /create_user_roadmap.php
GET /get_roadmap_steps.php?roadmap_id={id}
GET /my_roadmaps.php
DELETE /delete_roadmap.php

POST /generate_roadmap_v4.php

Request:
{
"user_id": 1,
"current_stream_id": 3,
"target_job_id": 12
}

Response:
{
"status": true,
"roadmap_id": 22
}

<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

include("../config/db.php");

$stream_id = $_GET['stream_id'];

$res = mysqli_query($conn, "SELECT * FROM streams WHERE stream_id = $stream_id");
echo json_encode(mysqli_fetch_assoc($res));

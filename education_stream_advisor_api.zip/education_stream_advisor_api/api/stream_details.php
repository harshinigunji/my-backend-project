<?php
error_reporting(0);
ini_set('display_errors', 0);

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

include("../config/db.php");
require_once("helpers/response.php");

/* ---------- VALIDATION ---------- */
if (!isset($_GET['stream_id'])) {
    error("stream_id is required", "INVALID_INPUT");
}

$stream_id = (int)$_GET['stream_id'];
if ($stream_id <= 0) {
    error("Invalid stream_id", "INVALID_INPUT");
}

/* ---------- CACHE ---------- */
$cacheDir  = __DIR__ . "/cache/";
$cacheFile = $cacheDir . "stream_$stream_id.json";

if (file_exists($cacheFile)) {
    echo file_get_contents($cacheFile);
    exit;
}

/* ---------- QUERY ---------- */
$res = mysqli_query($conn, "
    SELECT * FROM streams WHERE stream_id = $stream_id
");

if (!$res) {
    error("Database error");
}

$stream = mysqli_fetch_assoc($res);

if (!$stream) {
    error("Stream not found");
}

/* ---------- SAVE CACHE ---------- */
if (!is_dir($cacheDir)) {
    mkdir($cacheDir, 0777, true);
}

file_put_contents($cacheFile, json_encode([
    "status" => true,
    "data" => $stream
]));

/* ---------- RESPONSE ---------- */
success($stream);

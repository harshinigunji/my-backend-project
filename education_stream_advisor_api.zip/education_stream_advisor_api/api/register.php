<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");
include("../config/db.php");
header("Content-Type: application/json");

$data = json_decode(file_get_contents("php://input"), true);

$name = $data['name'] ?? '';
$email = $data['email'] ?? '';
$password = $data['password'] ?? '';

if (!$name || !$email || !$password) {
    echo json_encode(["status" => false, "error" => "All fields required"]);
    exit;
}

$hashedPassword = password_hash($password, PASSWORD_DEFAULT);

mysqli_query($conn, "
INSERT INTO users (name, email, password)
VALUES ('$name', '$email', '$hashedPassword')
");

echo json_encode(["status" => true, "message" => "User registered"]);

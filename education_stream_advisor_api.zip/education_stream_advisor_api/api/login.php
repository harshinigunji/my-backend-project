<?php
error_reporting(0);
ini_set('display_errors', 0);

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

include("../config/db.php");
require_once("helpers/response.php");

$data = json_decode(file_get_contents("php://input"), true);

$email = trim($data['email'] ?? '');
$password = $data['password'] ?? '';

if (!$email || !$password) {
    error("Email and password are required");
}

/* ---------- FETCH USER ---------- */
$res = mysqli_query($conn, "
SELECT user_id, password
FROM users
WHERE email = '$email'
");

if (mysqli_num_rows($res) == 0) {
    error("Invalid credentials");
}

$user = mysqli_fetch_assoc($res);

/* ---------- VERIFY PASSWORD ---------- */
if (!password_verify($password, $user['password'])) {
    error("Invalid credentials");
}

/* ---------- GENERATE TOKEN ---------- */
$token = bin2hex(random_bytes(32));

mysqli_query($conn, "
UPDATE users SET auth_token = '$token'
WHERE user_id = {$user['user_id']}
");

/* ---------- RESPONSE ---------- */
success([
    "user_id" => $user['user_id'],
    "token" => $token
]);

<?php
error_reporting(0);
ini_set('display_errors', 0);

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

include("../config/db.php");
require_once("helpers/response.php");

$res = mysqli_query($conn, "SELECT * FROM education_levels");

if (!$res) {
    error("Database error");
}

$data = [];
while ($row = mysqli_fetch_assoc($res)) {
    $data[] = $row;
}

success($data);

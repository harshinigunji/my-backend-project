<?php
error_reporting(0);
ini_set('display_errors', 0);

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

include("../config/db.php");
require_once("helpers/response.php");

/* ---------- VALIDATION ---------- */
if (!isset($_GET['stream_id'])) {
    error("stream_id is required", "INVALID_INPUT");
}

$stream_id = (int)$_GET['stream_id'];
if ($stream_id <= 0) {
    error("Invalid stream_id", "INVALID_INPUT");
}

/* ---------- CACHE ---------- */
$cacheDir  = __DIR__ . "/cache/";
$cacheFile = $cacheDir . "jobs_stream_$stream_id.json";

if (file_exists($cacheFile)) {
    echo file_get_contents($cacheFile);
    exit;
}

/* ---------- QUERY ---------- */
$res = mysqli_query($conn, "
    SELECT j.job_id, j.job_title, j.sector
    FROM stream_jobs sj
    JOIN jobs j ON sj.job_id = j.job_id
    WHERE sj.stream_id = $stream_id
");

if (!$res) {
    error("Database error");
}

$data = [];
while ($row = mysqli_fetch_assoc($res)) {
    $data[] = $row;
}

/* ---------- SAVE CACHE ---------- */
if (!is_dir($cacheDir)) {
    mkdir($cacheDir, 0777, true);
}

file_put_contents($cacheFile, json_encode([
    "status" => true,
    "data" => $data
]));

/* ---------- RESPONSE ---------- */
success($data);

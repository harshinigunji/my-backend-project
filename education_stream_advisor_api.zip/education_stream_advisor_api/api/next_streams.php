<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

include("../config/db.php");

$stream_id = $_GET['stream_id'];

$sql = "
SELECT s.stream_id, s.stream_name
FROM stream_progression sp
JOIN streams s ON sp.to_stream_id = s.stream_id
WHERE sp.from_stream_id = $stream_id
";

$res = mysqli_query($conn, $sql);
$data = [];

while ($row = mysqli_fetch_assoc($res)) {
    $data[] = $row;
}

echo json_encode($data);

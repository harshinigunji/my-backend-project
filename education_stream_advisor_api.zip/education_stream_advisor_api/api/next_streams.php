<?php
error_reporting(0);
ini_set('display_errors', 0);

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

include("../config/db.php");
require_once("helpers/response.php");

if (!isset($_GET['stream_id'])) {
    error("stream_id is required");
}

$stream_id = (int)$_GET['stream_id'];

$sql = "
SELECT s.stream_id, s.stream_name
FROM stream_progression sp
JOIN streams s ON sp.to_stream_id = s.stream_id
WHERE sp.from_stream_id = $stream_id
";

$res = mysqli_query($conn, $sql);

if (!$res) {
    error("Database error");
}

$data = [];
while ($row = mysqli_fetch_assoc($res)) {
    $data[] = $row;
}

success($data);

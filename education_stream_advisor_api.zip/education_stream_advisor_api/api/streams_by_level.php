<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

include("../config/db.php");

/* ---------- VALIDATE INPUT ---------- */
if (!isset($_GET['level_id'])) {
    echo json_encode([
        "status" => false,
        "error" => "level_id parameter is required"
    ]);
    exit;
}

$level_id = (int)$_GET['level_id'];

/* ---------- QUERY ---------- */
$res = mysqli_query($conn, "
SELECT * FROM streams
WHERE level_id = $level_id
");

if (!$res) {
    echo json_encode([
        "status" => false,
        "error" => mysqli_error($conn)
    ]);
    exit;
}

$data = [];
while ($row = mysqli_fetch_assoc($res)) {
    $data[] = $row;
}

/* ---------- RESPONSE ---------- */
echo json_encode([
    "status" => true,
    "data" => $data
]);

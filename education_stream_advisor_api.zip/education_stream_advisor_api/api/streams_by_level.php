<?php
error_reporting(0);
ini_set('display_errors', 0);

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

include("../config/db.php");
require_once("helpers/response.php");

/* ---------- VALIDATE INPUT ---------- */
if (!isset($_GET['level_id'])) {
    error("level_id parameter is required");
}

$level_id = (int)$_GET['level_id'];

$cacheDir = __DIR__ . "/cache/";
$cacheFile = $cacheDir . "streams_level_$level_id.json";

/* 1️⃣ Return cache if exists */
if (file_exists($cacheFile)) {
    echo file_get_contents($cacheFile);
    exit;
}

/* 2️⃣ Fetch from DB */
$res = mysqli_query($conn, "
    SELECT * FROM streams WHERE level_id = $level_id
");

$data = [];
while ($row = mysqli_fetch_assoc($res)) {
    $data[] = $row;
}

/* 3️⃣ Save cache */
if (!is_dir($cacheDir)) {
    mkdir($cacheDir, 0777, true);
}

file_put_contents($cacheFile, json_encode([
    "status" => true,
    "data" => $data
]));

/* 4️⃣ Return response */
success($data);

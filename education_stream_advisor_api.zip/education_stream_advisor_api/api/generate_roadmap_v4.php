<?php
include("../config/db.php");
header("Content-Type: application/json");

$user_id = $_POST['user_id'];
$current_stream_id = $_POST['current_stream_id'];
$target_job_id = $_POST['target_job_id'];

$step_order = 1;

/* ------------------------------
   CREATE ROADMAP
--------------------------------*/
mysqli_query($conn, "
INSERT INTO roadmaps (user_id, current_level_id, target_job_id)
VALUES ($user_id, $current_stream_id, $target_job_id)
");

$roadmap_id = mysqli_insert_id($conn);

/* ------------------------------
   FETCH CAREER RULE (IF ANY)
--------------------------------*/
$ruleRes = mysqli_query($conn, "
SELECT stop_at_stream_id, required_exam
FROM career_path_rules
WHERE job_id = $target_job_id
");

$career_rule = mysqli_fetch_assoc($ruleRes);
$stop_stream_id = $career_rule['stop_at_stream_id'] ?? null;
$required_job_exam = $career_rule['required_exam'] ?? null;

/* ------------------------------
   TRACK INSERTED EXAMS (NO DUPES)
--------------------------------*/
$inserted_exams = [];

/* ------------------------------
   ROADMAP GENERATION LOOP
--------------------------------*/
while (true) {

    /* Get current stream */
    $sRes = mysqli_query($conn, "
    SELECT stream_id, stream_name
    FROM streams
    WHERE stream_id = $current_stream_id
    ");

    if (mysqli_num_rows($sRes) == 0) break;

    $stream = mysqli_fetch_assoc($sRes);
    $stream_name = mysqli_real_escape_string($conn, $stream['stream_name']);

    /* Insert education step */
    mysqli_query($conn, "
    INSERT INTO roadmap_steps (roadmap_id, step_order, education_stage)
    VALUES ($roadmap_id, $step_order, '$stream_name')
    ");
    $step_order++;

    /* -------- STOP RULE (MOST IMPORTANT) -------- */
    if ($stop_stream_id !== null && $current_stream_id == $stop_stream_id) {

        /* Add required job exam (like UPSC, CLAT, CA Foundation) */
        if ($required_job_exam && !in_array($required_job_exam, $inserted_exams)) {
            $exam_name = mysqli_real_escape_string($conn, $required_job_exam);
            mysqli_query($conn, "
            INSERT INTO roadmap_steps (roadmap_id, step_order, exam_name)
            VALUES ($roadmap_id, $step_order, '$exam_name')
            ");
            $step_order++;
            $inserted_exams[] = $required_job_exam;
        }
        break;
    }

    /* -------- CHECK IF JOB IS ALREADY VALID HERE -------- */
    $jobCheck = mysqli_query($conn, "
    SELECT 1 FROM stream_jobs
    WHERE stream_id = $current_stream_id
    AND job_id = $target_job_id
    ");

    if (mysqli_num_rows($jobCheck) > 0 && $stop_stream_id === null) {
        break;
    }

    /* -------- ADD EDUCATION EXAMS (ONLY IF MOVING NEXT) -------- */
    $examRes = mysqli_query($conn, "
    SELECT e.exam_name
    FROM stream_exams se
    JOIN entrance_exams e ON se.exam_id = e.exam_id
    WHERE se.stream_id = $current_stream_id
    AND se.required = 'Yes'
    ");

    while ($exam = mysqli_fetch_assoc($examRes)) {
        if (!in_array($exam['exam_name'], $inserted_exams)) {
            $exam_name = mysqli_real_escape_string($conn, $exam['exam_name']);
            mysqli_query($conn, "
            INSERT INTO roadmap_steps (roadmap_id, step_order, exam_name)
            VALUES ($roadmap_id, $step_order, '$exam_name')
            ");
            $step_order++;
            $inserted_exams[] = $exam['exam_name'];
        }
    }

    /* -------- MOVE TO NEXT STREAM -------- */
    $nextRes = mysqli_query($conn, "
    SELECT to_stream_id
    FROM stream_progression
    WHERE from_stream_id = $current_stream_id
    ORDER BY priority DESC
    LIMIT 1
    ");

    if (mysqli_num_rows($nextRes) == 0) break;

    $next = mysqli_fetch_assoc($nextRes);
    $current_stream_id = $next['to_stream_id'];
}

/* ------------------------------
   FINAL JOB STEP
--------------------------------*/
$jobRes = mysqli_query($conn, "
SELECT job_title FROM jobs
WHERE job_id = $target_job_id
");

$job = mysqli_fetch_assoc($jobRes);
$job_title = mysqli_real_escape_string($conn, $job['job_title']);

mysqli_query($conn, "
INSERT INTO roadmap_steps (roadmap_id, step_order, stream_name)
VALUES ($roadmap_id, $step_order, '$job_title')
");

/* ------------------------------
   RESPONSE
--------------------------------*/
echo json_encode([
    "status" => true,
    "roadmap_id" => $roadmap_id,
    "message" => "System-generated roadmap created successfully (v4)"
]);

<?php
error_reporting(0);
ini_set('display_errors', 0);

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

include("../config/db.php");
require_once("helpers/response.php");

/* ======================================================
   HELPER: CHECK IF A STREAM CAN EVENTUALLY REACH A JOB
   ====================================================== */
function canReachJob($conn, $stream_id, $job_id, $depth = 0) {

    static $visited = [];

    if (isset($visited[$stream_id])) {
        return $visited[$stream_id];
    }

    if ($depth > 7) {
        return $visited[$stream_id] = false;
    }

    /* Direct job */
    $jobRes = mysqli_query($conn, "
        SELECT 1 FROM stream_jobs
        WHERE stream_id = $stream_id
        AND job_id = $job_id
    ");

    if (mysqli_num_rows($jobRes) > 0) {
        return $visited[$stream_id] = true;
    }

    /* Next streams */
    $nextRes = mysqli_query($conn, "
        SELECT to_stream_id FROM stream_progression
        WHERE from_stream_id = $stream_id
    ");

    while ($row = mysqli_fetch_assoc($nextRes)) {
        if (canReachJob($conn, $row['to_stream_id'], $job_id, $depth + 1)) {
            return $visited[$stream_id] = true;
        }
    }

    return $visited[$stream_id] = false;
}


/* ======================================================
   INPUT VALIDATION
   ====================================================== */
$user_id = (int)($_POST['user_id'] ?? 0);
$current_stream_id = (int)($_POST['current_stream_id'] ?? 0);
$target_job_id = (int)($_POST['target_job_id'] ?? 0);

if (!$user_id || !$current_stream_id || !$target_job_id) {
    error("Invalid input parameters");
}

/* ======================================================
   BASIC VALIDATIONS
   ====================================================== */
if (mysqli_num_rows(mysqli_query($conn, "SELECT 1 FROM users WHERE user_id=$user_id")) == 0)
    error("Invalid user");

if (mysqli_num_rows(mysqli_query($conn, "SELECT 1 FROM streams WHERE stream_id=$current_stream_id")) == 0)
    error("Invalid stream");

if (mysqli_num_rows(mysqli_query($conn, "SELECT 1 FROM jobs WHERE job_id=$target_job_id")) == 0)
    error("Invalid job");

/* ======================================================
   CREATE ROADMAP
   ====================================================== */
mysqli_query($conn, "
INSERT INTO roadmaps (user_id, current_level_id, target_job_id)
VALUES ($user_id, $current_stream_id, $target_job_id)
");

$roadmap_id = mysqli_insert_id($conn);
$step_order = 1;
$inserted_exams = [];

/* ======================================================
   ROADMAP GENERATION LOOP (TARGET-AWARE)
   ====================================================== */
while (true) {

    /* ---------- CURRENT STREAM ---------- */
    $streamRes = mysqli_query($conn, "
        SELECT stream_name FROM streams
        WHERE stream_id = $current_stream_id
    ");
    if (mysqli_num_rows($streamRes) == 0) break;

    $stream = mysqli_fetch_assoc($streamRes);

    mysqli_query($conn, "
        INSERT INTO roadmap_steps (roadmap_id, step_order, education_stage)
        VALUES ($roadmap_id, $step_order, '{$stream['stream_name']}')
    ");
    $step_order++;

    /* ---------- JOB POSSIBLE HERE? ---------- */
    $jobCheck = mysqli_query($conn, "
        SELECT 1 FROM stream_jobs
        WHERE stream_id = $current_stream_id
        AND job_id = $target_job_id
    ");
    if (mysqli_num_rows($jobCheck) > 0) break;

    /* ---------- FIND CORRECT NEXT STREAM ---------- */
    $nextRes = mysqli_query($conn, "
        SELECT to_stream_id
        FROM stream_progression
        WHERE from_stream_id = $current_stream_id
    ");

    $next_stream_id = null;

    while ($row = mysqli_fetch_assoc($nextRes)) {
        if (canReachJob($conn, $row['to_stream_id'], $target_job_id)) {
            $next_stream_id = $row['to_stream_id'];
            break;
        }
    }

    if (!$next_stream_id) {
    error(
        "No valid career path found for selected job",
        "NO_PATH"
    );
}


    /* ---------- ADD EXAMS REQUIRED TO ENTER NEXT STREAM ---------- */
    $examRes = mysqli_query($conn, "
        SELECT e.exam_name
        FROM stream_exams se
        JOIN entrance_exams e ON se.exam_id = e.exam_id
        WHERE se.stream_id = $next_stream_id
        AND se.required = 'Yes'
    ");

    while ($exam = mysqli_fetch_assoc($examRes)) {
        if (!in_array($exam['exam_name'], $inserted_exams)) {
            mysqli_query($conn, "
                INSERT INTO roadmap_steps (roadmap_id, step_order, exam_name)
                VALUES ($roadmap_id, $step_order, '{$exam['exam_name']}')
            ");
            $inserted_exams[] = $exam['exam_name'];
            $step_order++;
        }
    }

    /* ---------- MOVE FORWARD ---------- */
    $current_stream_id = $next_stream_id;
}

/* ======================================================
   FINAL JOB STEP
   ====================================================== */
$jobRes = mysqli_query($conn, "
    SELECT job_title FROM jobs
    WHERE job_id = $target_job_id
");
$job = mysqli_fetch_assoc($jobRes);

mysqli_query($conn, "
    INSERT INTO roadmap_steps (roadmap_id, step_order, stream_name)
    VALUES ($roadmap_id, $step_order, '{$job['job_title']}')
");

/* ======================================================
   RESPONSE
   ====================================================== */
success([
    "roadmap_id" => $roadmap_id,
    "message" => "System-generated roadmap created successfully"
]);

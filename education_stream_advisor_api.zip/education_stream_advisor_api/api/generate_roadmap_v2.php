<?php
include("../config/db.php");
header("Content-Type: application/json");

/*
EXPECTED INPUT (POST):
user_id
current_stream_id
target_job_id
*/

$user_id = $_POST['user_id'];
$current_stream_id = $_POST['current_stream_id'];
$target_job_id = $_POST['target_job_id'];

$step_order = 1;

/* -------------------------------
 STEP 1: CREATE ROADMAP
--------------------------------*/
$insertRoadmap = mysqli_query($conn, "
INSERT INTO roadmaps (user_id, current_level_id, target_job_id)
VALUES ($user_id, $current_stream_id, $target_job_id)
");

if (!$insertRoadmap) {
    echo json_encode([
        "status" => false,
        "error" => mysqli_error($conn)
    ]);
    exit;
}

$roadmap_id = mysqli_insert_id($conn);

/* -------------------------------
 STEP 2: LOOP THROUGH STREAMS
--------------------------------*/
while (true) {

    /* Get current stream name */
    $streamRes = mysqli_query($conn, "
    SELECT stream_name FROM streams
    WHERE stream_id = $current_stream_id
    ");

    if (mysqli_num_rows($streamRes) == 0) {
        break;
    }

    $stream = mysqli_fetch_assoc($streamRes);
    $stream_name = mysqli_real_escape_string($conn, $stream['stream_name']);

    /* Add education step */
    mysqli_query($conn, "
    INSERT INTO roadmap_steps (roadmap_id, step_order, education_stage)
    VALUES ($roadmap_id, $step_order, '$stream_name')
    ");
    $step_order++;

    /* -------------------------------
       STEP 3: ADD REQUIRED EXAMS
    --------------------------------*/
    $examRes = mysqli_query($conn, "
    SELECT e.exam_name
    FROM stream_exams se
    JOIN entrance_exams e ON se.exam_id = e.exam_id
    WHERE se.stream_id = $current_stream_id
    AND se.required = 'Yes'
    ");

    while ($exam = mysqli_fetch_assoc($examRes)) {
        $exam_name = mysqli_real_escape_string($conn, $exam['exam_name']);

        mysqli_query($conn, "
        INSERT INTO roadmap_steps (roadmap_id, step_order, exam_name)
        VALUES ($roadmap_id, $step_order, '$exam_name')
        ");
        $step_order++;
    }

    /* -------------------------------
       STEP 4: CHECK IF JOB REACHED
    --------------------------------*/
    $jobCheck = mysqli_query($conn, "
    SELECT 1 FROM stream_jobs
    WHERE stream_id = $current_stream_id
    AND job_id = $target_job_id
    ");

    if (mysqli_num_rows($jobCheck) > 0) {
        break; // job reachable, stop loop
    }

    /* -------------------------------
       STEP 5: MOVE TO NEXT STREAM
    --------------------------------*/
    $nextRes = mysqli_query($conn, "
    SELECT to_stream_id FROM stream_progression
    WHERE from_stream_id = $current_stream_id
    LIMIT 1
    ");

    if (mysqli_num_rows($nextRes) == 0) {
        break; // no further progression
    }

    $next = mysqli_fetch_assoc($nextRes);
    $current_stream_id = $next['to_stream_id'];
}

/* -------------------------------
 STEP 6: FINAL JOB STEP
--------------------------------*/
$jobRes = mysqli_query($conn, "
SELECT job_title FROM jobs
WHERE job_id = $target_job_id
");

$job = mysqli_fetch_assoc($jobRes);
$job_title = mysqli_real_escape_string($conn, $job['job_title']);

mysqli_query($conn, "
INSERT INTO roadmap_steps (roadmap_id, step_order, stream_name)
VALUES ($roadmap_id, $step_order, '$job_title')
");

/* -------------------------------
 RESPONSE
--------------------------------*/
echo json_encode([
    "status" => true,
    "roadmap_id" => $roadmap_id,
    "message" => "Roadmap generated successfully"
]);

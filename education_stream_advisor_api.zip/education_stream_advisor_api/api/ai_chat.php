<?php
// ================================
// ERROR SETTINGS (disable in prod)
// ================================
error_reporting(0);
ini_set('display_errors', 0);

// ================================
// HEADERS
// ================================
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json");

// ================================
// RESPONSE HELPERS
// ================================
function success($data = [])
{
    echo json_encode([
        "status" => true,
        "data" => $data
    ]);
    exit;
}

function error($message, $code = "ERROR")
{
    echo json_encode([
        "status" => false,
        "error_code" => $code,
        "message" => $message
    ]);
    exit;
}

// ================================
// READ INPUT
// ================================
$input = json_decode(file_get_contents("php://input"), true);
$question = trim($input['question'] ?? '');

if ($question === '') {
    error("Question is required", "INVALID_INPUT");
}

// ================================
// API CONFIG
// ================================
$API_KEY = "AIzaSyAOE_smXKl9Dbt-AvfwXz-9s94r8m66Hp4"; // 🔴 put your Gemini API key

$url = $url = $url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=" . $API_KEY;


// ================================
// PROMPT
// ================================
$prompt = "
You are a career guidance chatbot.

Rules:
- Reply in 1–2 sentences only
- Maximum 40 words
- Be friendly and direct

Question:
$question
";


// ================================
// PAYLOAD
// ================================
$payload = [
    "contents" => [
        [
            "parts" => [
                ["text" => $prompt]
            ]
        ]
    ]
];

// ================================
// CURL REQUEST
// ================================
$ch = curl_init($url);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_HTTPHEADER => ["Content-Type: application/json"],
    CURLOPT_POSTFIELDS => json_encode($payload),
    CURLOPT_TIMEOUT => 30
]);

$response = curl_exec($ch);

if (curl_errno($ch)) {
    curl_close($ch);
    error("Failed to connect to AI service", "CURL_ERROR");
}

curl_close($ch);

// ================================
// PARSE RESPONSE
// ================================
$result = json_decode($response, true);

if (
    !isset($result['candidates'][0]['content']['parts'][0]['text'])
) {
    error("AI response is unavailable", "AI_ERROR");
}

$reply = trim($result['candidates'][0]['content']['parts'][0]['text']);

// ================================
// SUCCESS RESPONSE
// ================================
success([
    "reply" => $reply
]);

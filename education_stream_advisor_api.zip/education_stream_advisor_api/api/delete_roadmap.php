<?php
error_reporting(0);
ini_set('display_errors', 0);

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

include("../config/db.php");
require_once("helpers/response.php");
require_once("helpers/auth.php");

/* ---------- AUTHENTICATE USER ---------- */
$user_id = authenticate($conn);

/* ---------- READ INPUT ---------- */
$data = json_decode(file_get_contents("php://input"), true);

$roadmap_id = (int)($data['roadmap_id'] ?? 0);

if ($roadmap_id <= 0) {
    error("Invalid roadmap_id");
}

/* ---------- CHECK OWNERSHIP ---------- */
$check = mysqli_query($conn, "
SELECT 1 FROM roadmaps
WHERE roadmap_id = $roadmap_id
AND user_id = $user_id
");

if (!$check || mysqli_num_rows($check) === 0) {
    error("Access denied or roadmap not found");
}

/* ---------- DELETE ROADMAP STEPS ---------- */
mysqli_query($conn, "
DELETE FROM roadmap_steps
WHERE roadmap_id = $roadmap_id
");

/* ---------- DELETE ROADMAP ---------- */
mysqli_query($conn, "
DELETE FROM roadmaps
WHERE roadmap_id = $roadmap_id
");

/* ---------- RESPONSE ---------- */
success([
    "message" => "Roadmap deleted successfully"
]);

<?php
error_reporting(0);
ini_set('display_errors', 0);

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

include("../config/db.php");
require_once("helpers/response.php");
//require_once("helpers/auth.php");

/* ---------- AUTHENTICATE USER ---------- */
//$user_id = authenticate($conn);

$user_id = (int)($_POST['user_id'] ?? 0);

/* ---------- VALIDATE INPUT ---------- */
if (!isset($_GET['roadmap_id'])) {
    error("roadmap_id is required");
}

$roadmap_id = (int)$_GET['roadmap_id'];

if ($roadmap_id <= 0) {
    error("Invalid roadmap_id");
}

/* ---------- CHECK ROADMAP OWNERSHIP ---------- */
$check = mysqli_query($conn, "
SELECT 1 FROM roadmaps
WHERE roadmap_id = $roadmap_id
");

if (!$check || mysqli_num_rows($check) === 0) {
    error("Access denied or roadmap not found");
}

/* ---------- FETCH ROADMAP STEPS ---------- */
$res = mysqli_query($conn, "
SELECT step_order,
       education_stage,
       stream_name,
       exam_name
FROM roadmap_steps
WHERE roadmap_id = $roadmap_id
ORDER BY step_order
");

if (!$res) {
    error("Database error");
}

$data = [];
while ($row = mysqli_fetch_assoc($res)) {
    $data[] = $row;
}

if (empty($data)) {
    success([]);
}


/* ---------- RESPONSE ---------- */
success($data);

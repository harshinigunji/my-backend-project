<?php
error_reporting(0);
ini_set('display_errors', 0);

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

include("../config/db.php");
require_once("helpers/response.php");

$data = json_decode(file_get_contents("php://input"), true);

// require_once("helpers/auth.php");
// $user_id = authenticate($conn);

$user_id = (int)($data['user_id'] ?? 0);
$current_level_id = (int)($data['current_level_id'] ?? 0);
$target_job_id = (int)($data['target_job_id'] ?? 0);
$steps = $data['steps'] ?? [];

if (!$user_id || empty($steps)) {
    error("Invalid input");
}

/* ---------- CREATE ROADMAP ---------- */
$res = mysqli_query($conn, "
INSERT INTO roadmaps (user_id, current_level_id, target_job_id)
VALUES ($user_id, $current_level_id, $target_job_id)
");

if (!$res) {
    error("Failed to create roadmap");
}

$roadmap_id = mysqli_insert_id($conn);
$step_order = 1;

/* ---------- INSERT USER STEPS ---------- */
foreach ($steps as $step) {

    if (!isset($step['type'], $step['value'])) {
        continue;
    }

    $type = mysqli_real_escape_string($conn, $step['type']);
    $value = mysqli_real_escape_string($conn, $step['value']);

    if ($type === "education") {
        mysqli_query($conn, "
        INSERT INTO roadmap_steps (roadmap_id, step_order, step_type, education_stage)
        VALUES ($roadmap_id, $step_order, 'education', '$value')
        ");
    } elseif ($type === "exam") {
        mysqli_query($conn, "
        INSERT INTO roadmap_steps (roadmap_id, step_order, step_type, exam_name)
        VALUES ($roadmap_id, $step_order, 'exam', '$value')
        ");
    } elseif ($type === "job") {
        mysqli_query($conn, "
        INSERT INTO roadmap_steps (roadmap_id, step_order, step_type, stream_name)
        VALUES ($roadmap_id, $step_order, 'job', '$value')
        ");
    }

    $step_order++;
}

success([
    "roadmap_id" => $roadmap_id,
    "message" => "User roadmap created successfully"
]);

<?php
error_reporting(0);
ini_set('display_errors', 0);

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

include("../config/db.php");
require_once("helpers/response.php");

/* ---------- VALIDATION ---------- */
if (!isset($_GET['exam_id'])) {
    error("exam_id is required", "INVALID_INPUT");
}

$exam_id = (int)$_GET['exam_id'];
if ($exam_id <= 0) {
    error("Invalid exam_id", "INVALID_INPUT");
}

/* ---------- CACHE ---------- */
$cacheDir  = __DIR__ . "/cache/";
$cacheFile = $cacheDir . "exam_$exam_id.json";

if (file_exists($cacheFile)) {
    echo file_get_contents($cacheFile);
    exit;
}

/* ---------- QUERY ---------- */
$res = mysqli_query($conn, "
    SELECT * FROM entrance_exams WHERE exam_id = $exam_id
");

if (!$res) {
    error("Database error");
}

$exam = mysqli_fetch_assoc($res);

if (!$exam) {
    error("Exam not found");
}

/* ---------- SAVE CACHE ---------- */
if (!is_dir($cacheDir)) {
    mkdir($cacheDir, 0777, true);
}

file_put_contents($cacheFile, json_encode([
    "status" => true,
    "data" => $exam
]));

/* ---------- RESPONSE ---------- */
success($exam);

<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

include("../config/db.php");

$start_stream = $_GET['start_stream_id'];
$target_job = $_GET['target_job_id'];

$roadmap = [];

/* Start */
$roadmap[] = ["type" => "stream", "id" => $start_stream];

/* Required Exams */
$examSQL = "
SELECT e.exam_name
FROM stream_exams se
JOIN entrance_exams e ON se.exam_id = e.exam_id
WHERE se.stream_id = $start_stream AND se.required = 'Required'
";

$res = mysqli_query($conn, $examSQL);
while ($row = mysqli_fetch_assoc($res)) {
    $roadmap[] = ["type" => "exam", "name" => $row['exam_name']];
}

/* Target Job */
$roadmap[] = ["type" => "job", "id" => $target_job];

echo json_encode($roadmap);

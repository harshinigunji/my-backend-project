<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

include("../config/db.php");

if (!isset($_GET['stream_id'])) {
    echo json_encode([
        "status" => false,
        "error" => "stream_id is required"
    ]);
    exit;
}

$stream_id = (int)$_GET['stream_id'];

$res = mysqli_query($conn, "
SELECT DISTINCT 
    e.exam_id,
    e.exam_name,
    se.required
FROM stream_exams se
JOIN entrance_exams e ON se.exam_id = e.exam_id
WHERE se.stream_id = $stream_id
");

if (!$res) {
    echo json_encode([
        "status" => false,
        "error" => mysqli_error($conn)
    ]);
    exit;
}

$data = [];
while ($row = mysqli_fetch_assoc($res)) {
    $data[] = $row;
}

echo json_encode([
    "status" => true,
    "data" => $data
]);

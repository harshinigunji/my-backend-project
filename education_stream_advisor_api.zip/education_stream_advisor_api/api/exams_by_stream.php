<?php
error_reporting(0);
ini_set('display_errors', 0);

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

include("../config/db.php");
require_once("helpers/response.php");

/* ---------- INPUT VALIDATION ---------- */
if (!isset($_GET['stream_id'])) {
    error("stream_id is required", "INVALID_INPUT");
}

$stream_id = (int)$_GET['stream_id'];

/* ---------- CACHE SETUP ---------- */
$cacheDir  = __DIR__ . "/cache/";
$cacheFile = $cacheDir . "exams_stream_$stream_id.json";

/* ---------- RETURN CACHE IF EXISTS ---------- */
if (file_exists($cacheFile)) {
    echo file_get_contents($cacheFile);
    exit;
}

/* ---------- DATABASE QUERY ---------- */
$res = mysqli_query($conn, "
    SELECT DISTINCT 
        e.exam_id,
        e.exam_name,
        se.required
    FROM stream_exams se
    JOIN entrance_exams e ON se.exam_id = e.exam_id
    WHERE se.stream_id = $stream_id
");

if (!$res) {
    error("Something went wrong. Please try again later.");
}

/* ---------- FETCH DATA ---------- */
$data = [];
while ($row = mysqli_fetch_assoc($res)) {
    $data[] = $row;
}

/* ---------- ENSURE CACHE DIRECTORY EXISTS ---------- */
if (!is_dir($cacheDir)) {
    mkdir($cacheDir, 0777, true);
}

/* ---------- SAVE CACHE ---------- */
file_put_contents($cacheFile, json_encode([
    "status" => true,
    "data" => $data
]));

/* ---------- RESPONSE ---------- */
if (empty($data)) {
    success([]);
}

success($data);

<?php
error_reporting(0);
ini_set('display_errors', 0);

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

include("../config/db.php");
require_once("helpers/response.php");
require_once("helpers/auth.php");

/* ---------- AUTHENTICATE USER ---------- */
$user_id = authenticate($conn);

/* ---------- FETCH USER ROADMAPS ---------- */
$res = mysqli_query($conn, "
SELECT 
    r.roadmap_id,
    r.created_at,
    s.stream_name AS current_stream,
    j.job_title AS target_job
FROM roadmaps r
LEFT JOIN streams s ON r.current_level_id = s.stream_id
LEFT JOIN jobs j ON r.target_job_id = j.job_id
WHERE r.user_id = $user_id
ORDER BY r.created_at DESC
");

if (!$res) {
    error("Database error");
}

$data = [];
while ($row = mysqli_fetch_assoc($res)) {
    $data[] = $row;
}

/* ---------- RESPONSE ---------- */
success($data);
